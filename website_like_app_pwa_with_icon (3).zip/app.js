function navigate(page) {
  const content = document.getElementById('content');

  if (page === 'home') {
    content.innerHTML = `<h2>হোম</h2><p>এটা হোমপেজ।</p>`;
  } else if (page === 'about') {
    content.innerHTML = `<h2>আমাদের সম্পর্কে</h2><p>আমরা অ্যাপ তৈরি করি!</p>`;
  } else if (page === 'contact') {
    content.innerHTML = `<h2>যোগাযোগ</h2><p>ইমেইল: example@example.com</p>`;
  }
}
